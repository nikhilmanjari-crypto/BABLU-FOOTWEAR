// BABLU FOOTWEAR storefront — static frontend. Product records load from data/products.json.
const CFG = window.BABLU_CONFIG || {whatsappNumber:"",markupAmount:200,delivery:{allowedPincodes:[]}};
let products = [], cart = JSON.parse(localStorage.getItem("bablu_cart") || "[]");
const $ = s => document.querySelector(s);
const money = n => new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:0}).format(n || 0);
const esc = s => String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2300)}
function persist(){localStorage.setItem("bablu_cart",JSON.stringify(cart));renderCart()}
function validProduct(p){return p && p.id && p.name && p.brand && p.category && Number.isFinite(Number(p.referencePrice)) && Number(p.sellingPrice)===Number(p.referencePrice)+Number(CFG.markupAmount||200) && p.image && p.status==="active"}
function initFilters(){
  const cats=[...new Set(products.map(p=>p.category))].sort(), brands=[...new Set(products.map(p=>p.brand))].sort(), sizes=[...new Set(products.flatMap(p=>p.sizes||[]))].sort((a,b)=>String(a).localeCompare(String(b),undefined,{numeric:true}));
  $("#categoryFilter").innerHTML='<option value="">All categories</option>'+cats.map(x=>`<option>${esc(x)}</option>`).join("");
  $("#brandFilter").innerHTML='<option value="">All brands</option>'+brands.map(x=>`<option>${esc(x)}</option>`).join("");
  $("#sizeFilter").innerHTML='<option value="">Any size</option>'+sizes.map(x=>`<option>${esc(x)}</option>`).join("");
}
function filtered(){
 let a=products.filter(p=>{
  const q=$("#searchInput").value.trim().toLowerCase(), hay=[p.name,p.brand,p.model,p.category,p.subcategory].join(" ").toLowerCase();
  return (!q||hay.includes(q))&&(!$("#genderFilter").value||p.gender===$("#genderFilter").value)&&(!$("#categoryFilter").value||p.category===$("#categoryFilter").value)&&(!$("#brandFilter").value||p.brand===$("#brandFilter").value)&&(!$("#sizeFilter").value||(p.sizes||[]).map(String).includes($("#sizeFilter").value))&&Number(p.sellingPrice)<=Number($("#maxPrice").value);
 });
 const sort=$("#sortFilter").value;
 if(sort==="low")a.sort((x,y)=>x.sellingPrice-y.sellingPrice); if(sort==="high")a.sort((x,y)=>y.sellingPrice-x.sellingPrice); if(sort==="az")a.sort((x,y)=>x.name.localeCompare(y.name));
 return a;
}
function renderProducts(){
 const a=filtered(); $("#productGrid").innerHTML=a.map(p=>`<article class="product-card"><div class="product-photo"><img loading="lazy" src="${esc(p.image)}" alt="${esc(p.name)}" onerror="this.parentElement.innerHTML='<span class=&quot;pending-mark&quot;>BF</span>'"></div><div class="product-info"><div class="product-meta">${esc(p.brand)} · ${esc(p.category)}</div><div class="product-name">${esc(p.name)}</div><div class="product-price">${money(p.sellingPrice)}</div><button class="quick-add" data-add="${esc(p.id)}">SELECT SIZE & ADD</button></div></article>`).join("");
 $("#emptyState").classList.toggle("show",a.length===0);
 $("#catalogStatus").textContent=`${products.length} verified products currently listed`;
 $("#productGrid").querySelectorAll("[data-add]").forEach(b=>b.addEventListener("click",()=>addProduct(b.dataset.add)));
}
function addProduct(id){
 const p=products.find(x=>x.id===id); if(!p)return;
 const size=prompt(`Available sizes: ${(p.sizes||[]).join(", ")}\nEnter your size:`); if(!size)return;
 if(!(p.sizes||[]).map(String).includes(size.trim()))return toast("That size is not listed.");
 const existing=cart.find(x=>x.id===id&&x.size===size.trim());
 if(existing)existing.qty++;else cart.push({id:p.id,name:p.name,brand:p.brand,price:Number(p.sellingPrice),size:size.trim(),qty:1});
 persist();toast("Added to your bag.");
}
function renderCart(){
 $("#bagCount").textContent=cart.reduce((n,x)=>n+x.qty,0);
 $("#cartItems").innerHTML=cart.length?cart.map((x,i)=>`<div class="cart-line"><div class="cart-thumb">BF</div><div><strong>${esc(x.name)}</strong><small>${esc(x.brand)} · Size ${esc(x.size)} · Qty ${x.qty}</small><small>${money(x.price*x.qty)}</small><button data-remove="${i}">Remove</button></div><div>${money(x.price)}</div></div>`).join(""):'<p class="fine-print">Your bag is empty. Explore the catalogue to add a pair.</p>';
 $("#cartItems").querySelectorAll("[data-remove]").forEach(b=>b.addEventListener("click",()=>{cart.splice(Number(b.dataset.remove),1);persist()}));
 const total=cart.reduce((n,x)=>n+x.price*x.qty,0);$("#cartTotal").textContent=money(total);$("#checkoutTotal").textContent=money(total);
}
function openCart(){$("#overlay").classList.add("open");$("#cartDrawer").classList.add("open")}
function closeCart(){$("#overlay").classList.remove("open");$("#cartDrawer").classList.remove("open")}
$("#bagOpen").onclick=openCart;$("#cartClose").onclick=closeCart;$("#overlay").onclick=closeCart;
$("#checkoutStart").onclick=()=>{if(!cart.length)return toast("Your bag is empty.");closeCart();$("#checkoutModal").classList.add("open")};
$("#checkoutClose").onclick=()=>$("#checkoutModal").classList.remove("open");
$("#fulfilment").onchange=()=>{const pickup=$("#fulfilment").value==="Store pickup";$("#addressField").required=!pickup;$("#pincodeField").required=!pickup;$("#addressField").disabled=pickup;$("#pincodeField").disabled=pickup};
$("#checkoutForm").onsubmit=e=>{
 e.preventDefault(); if(!cart.length)return toast("Your bag is empty.");
 const f=new FormData(e.target), name=f.get("name").trim(), phone=f.get("phone").trim(), mode=f.get("fulfilment"), pin=f.get("pincode").trim();
 if(mode==="Local delivery"&&CFG.delivery.allowedPincodes?.length&&!CFG.delivery.allowedPincodes.includes(pin))return toast("This pincode is outside the configured delivery area.");
 const lines=cart.map(x=>`• ${x.name} (${x.brand}) | Size: ${x.size} | Qty: ${x.qty} | ${money(x.price*x.qty)}`);
 const total=cart.reduce((n,x)=>n+x.price*x.qty,0);
 const msg=[`BABLU FOOTWEAR — NEW ORDER`,`Name: ${name}`,`Mobile: ${phone}`,`Fulfilment: ${mode}`,mode==="Local delivery"?`Address: ${f.get("address")}, Pincode: ${pin}`:"",`Instructions: ${f.get("instructions")||"—"}`,"","ITEMS",...lines,"",`TOTAL: ${money(total)}`,"Please confirm availability and delivery/pickup details."].filter(Boolean).join("\n");
 const number=String(CFG.whatsappNumber||"").replace(/\D/g,""); if(number.length<10||number.includes("XXXXXXXX"))return toast("Store WhatsApp number is not configured.");
 window.open(`https://wa.me/${number}?text=${encodeURIComponent(msg)}`,"_blank","noopener");
};
["searchInput","genderFilter","categoryFilter","brandFilter","sizeFilter","sortFilter","maxPrice"].forEach(id=>$("#"+id).addEventListener("input",()=>{if(id==="maxPrice")$("#priceLabel").textContent=money($("#maxPrice").value);renderProducts()}));
$("#searchToggle").onclick=()=>{$("#searchInput").focus();$("#shop").scrollIntoView({behavior:"smooth"})};
$("#menuToggle").onclick=()=>$("#mobileNav").classList.toggle("open");
document.querySelectorAll("[data-gender]").forEach(a=>a.addEventListener("click",()=>{$("#genderFilter").value=a.dataset.gender;renderProducts();$("#mobileNav").classList.remove("open")}));
document.querySelectorAll("[data-category]").forEach(b=>b.addEventListener("click",()=>{$("#categoryFilter").value=[...$("#categoryFilter").options].some(o=>o.value===b.dataset.category)?b.dataset.category:"";renderProducts();$("#shop").scrollIntoView({behavior:"smooth"})}));
$("#year").textContent=new Date().getFullYear();
fetch("data/products.json").then(r=>{if(!r.ok)throw Error("catalogue");return r.json()}).then(d=>{
 products=(d.products||[]).filter(validProduct);
 initFilters();renderProducts();
 if(d.targetCount)$("#catalogStatus").textContent=`${products.length} / ${d.targetCount} verified products`;
}).catch(()=>{products=[];initFilters();renderProducts();$("#catalogStatus").textContent="Catalogue data unavailable"});
renderCart();