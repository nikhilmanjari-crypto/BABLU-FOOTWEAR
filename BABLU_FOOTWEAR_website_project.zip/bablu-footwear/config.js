// Store configuration. Replace these values before launch.
window.BABLU_CONFIG = {
  whatsappNumber: "91XXXXXXXXXX", // International format, digits only. Example: 919876543210
  currency: "INR",
  markupAmount: 200,
  delivery: {
    // Add allowed pincodes. Leave empty only if your team manually checks every delivery.
    allowedPincodes: [],
    storePickupEnabled: true
  },
  // This is a client-side convenience gate, NOT secure production authentication.
  adminPin: "CHANGE-ME"
};