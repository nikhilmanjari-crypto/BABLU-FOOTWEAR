#!/usr/bin/env python3
"""Validate product records, ₹200 markup, required fields, duplicate IDs/images and reachable image URLs.
Run: python scripts/validate_catalogue.py
Network checks require internet access. This script does not determine image licensing or visual match.
"""
import json, sys, urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
data=json.loads((ROOT/"data/products.json").read_text(encoding="utf-8"))
products=data.get("products",[])
required=["id","name","brand","model","gender","category","subcategory","referencePrice","sellingPrice","description","sizes","image","sourceUrl","status"]
errors=[]; ids={}; images={}
for i,p in enumerate(products,1):
    for k in required:
        if k not in p or p[k] in (None,"",[]): errors.append(f"row {i}: missing {k}")
    pid=p.get("id")
    if pid in ids: errors.append(f"duplicate product ID {pid}")
    ids[pid]=i
    img=p.get("image")
    if img:
        if img in images: errors.append(f"duplicate image URL used by {pid} and {images[img]}")
        images[img]=pid
    try:
        if float(p["sellingPrice"]) != float(p["referencePrice"])+200:
            errors.append(f"{pid}: selling price is not reference + ₹200")
    except Exception: errors.append(f"{pid}: invalid price fields")
    if p.get("status")=="active" and (not p.get("priceVerified") or not p.get("imageRightsVerified")):
        errors.append(f"{pid}: active item lacks price/image-rights verification flags")
print(f"Catalogue records: {len(products)} / target {data.get('targetCount',600)}")
print(f"Unique IDs: {len(ids)} | Unique image URLs: {len(images)}")
if "--check-images" in sys.argv:
    for p in products:
        url=p.get("image","")
        if not url.startswith("https://"): errors.append(f"{p.get('id')}: image URL must use HTTPS"); continue
        try:
            req=urllib.request.Request(url,method="HEAD",headers={"User-Agent":"BABLU-Catalogue-Validator/1.0"})
            with urllib.request.urlopen(req,timeout=12) as r:
                if r.status>=400: errors.append(f"{p.get('id')}: image HTTP {r.status}")
        except Exception as e: errors.append(f"{p.get('id')}: image check failed ({e})")
if errors:
    print("\nVALIDATION ERRORS:")
    print("\n".join("- "+e for e in errors))
    sys.exit(1)
print("Structural validation passed. Note: URL reachability does not prove image match, licence, or product authenticity.")