# BABLU FOOTWEAR — fresh e-commerce project

A responsive static storefront foundation for Netlify. Built from a clean project; no previous NOXERA files are required.

## Important catalogue status

This delivery intentionally contains **0 researched products out of the requested 600**. It does not invent products, prices, brands, or pretend that product photographs are licensed. The storefront therefore displays a catalogue-verification empty state until verified records are added.

The project includes:
- Responsive premium black/ivory/gold storefront
- Search, gender/category/brand/size filters, price filter and sorting
- Persistent cart using LocalStorage
- Size selection and quantity aggregation
- Delivery/store-pickup customer form
- WhatsApp order message generation
- Local catalogue editor and JSON export
- Product schema and validation script

## Configure before testing

1. Open `config.js`.
2. Replace `91XXXXXXXXXX` with the store WhatsApp number in international digits-only format.
3. Set delivery pincodes in `delivery.allowedPincodes`. An empty list means the store team must manually verify each delivery request.
4. Change `adminPin`. This is only a local editor gate, not production security.

## Product data format

Add researched products to `data/products.json`. A product should look like:

```json
{
  "id": "BF-M-0001",
  "name": "Exact verified product name",
  "brand": "Actual brand",
  "model": "Verified model",
  "gender": "men",
  "category": "Sneakers",
  "subcategory": "Low-top",
  "referencePrice": 1299,
  "sellingPrice": 1499,
  "description": "Accurate product description.",
  "sizes": ["7", "8", "9", "10"],
  "image": "https://your-authorized-image-host.example/product.jpg",
  "sourceUrl": "https://source-listing.example/item",
  "priceVerified": true,
  "imageRightsVerified": true,
  "status": "active"
}
```

`sellingPrice` must equal `referencePrice + 200`. Use `status: "pending"` until product identity, reference price, image match and image-use rights have been checked. Do not copy marketplace images unless the relevant terms, licence or written permission allow it. A public image URL is not automatically permission to reuse it.

## Admin limitations — read before launch

`admin.html` is a browser-local editor. It does **not** write to the deployed JSON file, synchronize across devices, provide secure authentication, or protect the product database. The PIN is visible in client-side source and must not be treated as a secret. For a real public store, connect a backend such as Supabase/Firebase or a custom API with:
- server-side authentication and role-based access
- database-backed products, inventory and orders
- private image upload/storage
- server-side price calculation and order validation
- audit logs and backups

The WhatsApp flow is an order enquiry, not payment processing or a confirmed order. Store staff must confirm stock, delivery eligibility and final charges.

## Validate catalogue

From the project root:

```bash
python scripts/validate_catalogue.py
python scripts/validate_catalogue.py --check-images
```

The second command checks HTTPS image URL reachability. It cannot verify visual match or legal image rights. Manually inspect each image against the exact model and keep proof of authorization/licensing.

## Deploy to Netlify

1. Extract the ZIP.
2. Open Netlify and choose **Add new site → Deploy manually**.
3. Drag the extracted `bablu-footwear` folder (the folder containing `index.html`) into the deploy area.
4. After deployment, test on a phone and desktop.
5. Re-deploy after replacing `data/products.json` or configuration.

No build command is needed; publish directory is the project root.

## What is not complete

- 600-product research: 0/600
- verified reference prices: 0
- authorized matching product photos: 0
- production database and secure admin: not connected
- live domain, payment gateway, shipping integration: not configured
- live deployment and real-device QA: not performed

This is a working storefront foundation, not a completed 600-SKU production store.
